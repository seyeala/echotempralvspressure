Example layout this tool understands:

/data/MyFolder
  ├── pressure.csv
  ├── echo_A.csv
  └── echo_B.csv

/data/AnotherFolder
  ├── pressure.csv
  └── wave01.csv
